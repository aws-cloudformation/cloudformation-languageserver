"""A module containing constants."""

BOTO3_CONNECT_TIMEOUT = 5
