__all__ = ["BasePlugin"]

from samtranslator.plugins import BasePlugin
