"""CloudFormation attributes module."""
