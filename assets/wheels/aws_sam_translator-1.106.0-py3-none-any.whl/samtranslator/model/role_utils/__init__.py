__all__ = ["construct_role_for_resource"]

from .role_constructor import construct_role_for_resource
